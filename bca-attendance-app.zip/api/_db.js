import { neon } from '@neondatabase/serverless';
import { ROSTER } from './_roster.js';

export const sql = neon(process.env.DATABASE_URL || process.env.POSTGRES_URL);

let ready;
export const init = () => ready ||= (async () => {
  await sql`create table if not exists students(roll text primary key, name text not null)`;
  await sql`create table if not exists sessions(
    id serial primary key, date date not null, period int not null default 0,
    subject text not null, absent jsonb not null default '[]',
    created_at timestamptz default now(), unique(date, period, subject))`;
  await sql`insert into students select x->>0, x->>1
    from jsonb_array_elements(${JSON.stringify(ROSTER)}::jsonb) x on conflict do nothing`;
})().catch(e => { ready = null; throw e; });

export const authed = req => !!process.env.ADMIN_PIN && req.headers['x-pin'] === process.env.ADMIN_PIN;

export const wrap = fn => async (req, res) => {
  try { await init(); await fn(req, res); }
  catch (e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
};
