import { authed } from './_db.js';
export default (req, res) =>
  authed(req) ? res.json({ ok: true }) : res.status(401).json({ error: 'Wrong PIN' });
