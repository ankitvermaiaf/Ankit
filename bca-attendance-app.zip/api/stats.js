import { sql, wrap } from './_db.js';

// Every student with total classes held and classes missed.
export default wrap(async (req, res) => {
  res.json(await sql`
    select st.roll, st.name, count(se.id)::int as total,
           count(se.id) filter (where se.absent ? st.roll)::int as absent
    from students st left join sessions se on true
    group by st.roll, st.name order by st.roll`);
});
