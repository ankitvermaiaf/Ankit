import { sql, authed, wrap } from './_db.js';

export default wrap(async (req, res) => {
  if (req.method === 'GET') {
    const { date } = req.query;
    const rows = date
      ? await sql`select id, to_char(date,'YYYY-MM-DD') as date, period, subject, absent from sessions where date = ${date} order by period`
      : await sql`select id, to_char(date,'YYYY-MM-DD') as date, period, subject, absent from sessions order by sessions.date desc, period limit 200`;
    return res.json(rows);
  }
  if (!authed(req)) return res.status(401).json({ error: 'Wrong or missing PIN' });

  if (req.method === 'POST') {
    const { date, period = 0, subject, absent = [] } = req.body || {};
    if (!/^\d{4}-\d\d-\d\d$/.test(date) || !subject || !Array.isArray(absent))
      return res.status(400).json({ error: 'Bad data' });
    const [r] = await sql`insert into sessions(date, period, subject, absent)
      values(${date}, ${period}, ${String(subject).slice(0, 60)}, ${JSON.stringify(absent)}::jsonb)
      on conflict(date, period, subject) do update set absent = excluded.absent returning id`;
    return res.json({ id: r.id });
  }
  if (req.method === 'DELETE') {
    await sql`delete from sessions where id = ${+req.query.id}`;
    return res.json({ ok: true });
  }
  res.status(405).end();
});
