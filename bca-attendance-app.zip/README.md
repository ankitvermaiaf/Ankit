# BCA Attendance (Vercel + Neon Postgres)

1. Push this folder to a GitHub repo, then Vercel -> Add New -> Project -> Import it (Framework: Other).
2. Vercel project -> Storage -> Create Database -> Neon (Postgres) -> Connect to this project. This adds DATABASE_URL.
3. Project -> Settings -> Environment Variables -> add ADMIN_PIN = your secret PIN.
4. Deployments -> Redeploy. Tables and the roster are created automatically on the first request.

Anyone with the link can view. Only people who know ADMIN_PIN can mark or delete.
